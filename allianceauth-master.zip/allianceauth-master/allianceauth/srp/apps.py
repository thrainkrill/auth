from django.apps import AppConfig


class SRPConfig(AppConfig):
    name = 'allianceauth.srp'
    label = 'srp'
