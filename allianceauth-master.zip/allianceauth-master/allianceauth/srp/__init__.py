default_app_config = 'allianceauth.srp.apps.SRPConfig'

