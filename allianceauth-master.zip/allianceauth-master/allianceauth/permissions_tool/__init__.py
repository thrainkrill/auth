default_app_config = 'allianceauth.permissions_tool.apps.PermissionsToolConfig'
