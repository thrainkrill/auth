from django.apps import AppConfig


class Ips4ServiceConfig(AppConfig):
    name = 'allianceauth.services.modules.ips4'
    label = 'ips4'
