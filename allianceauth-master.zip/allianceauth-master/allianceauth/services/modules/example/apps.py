from django.apps import AppConfig


class ExampleServiceConfig(AppConfig):
    name = 'allianceauth.services.modules.example'
    label = 'example_service'
