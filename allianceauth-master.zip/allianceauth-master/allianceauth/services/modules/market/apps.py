from django.apps import AppConfig


class MarketServiceConfig(AppConfig):
    name = 'allianceauth.services.modules.market'
    label = 'market'
