from django.apps import AppConfig


class SeatServiceConfig(AppConfig):
    name = 'allianceauth.services.modules.seat'
    label = 'seat'
