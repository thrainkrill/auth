default_app_config = 'allianceauth.services.modules.phpbb3.apps.Phpbb3ServiceConfig'
