from django.apps import AppConfig


class DiscourseServiceConfig(AppConfig):
    name = 'allianceauth.services.modules.discourse'
    label = 'discourse'
