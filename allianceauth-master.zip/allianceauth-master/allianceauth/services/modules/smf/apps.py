from django.apps import AppConfig


class SmfServiceConfig(AppConfig):
    name = 'allianceauth.services.modules.smf'
    label = 'smf'
