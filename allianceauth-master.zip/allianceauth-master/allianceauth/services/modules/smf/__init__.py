default_app_config = 'allianceauth.services.modules.smf.apps.SmfServiceConfig'
