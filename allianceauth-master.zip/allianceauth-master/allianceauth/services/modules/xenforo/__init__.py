default_app_config = 'allianceauth.services.modules.xenforo.apps.XenforoServiceConfig'
