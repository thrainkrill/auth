from django.apps import AppConfig


class XenforoServiceConfig(AppConfig):
    name = 'allianceauth.services.modules.xenforo'
    label = 'xenforo'
