default_app_config = 'allianceauth.services.modules.teamspeak3.apps.Teamspeak3ServiceConfig'
