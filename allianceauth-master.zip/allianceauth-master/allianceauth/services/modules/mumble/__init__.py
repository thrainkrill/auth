default_app_config = 'allianceauth.services.modules.mumble.apps.MumbleServiceConfig'
