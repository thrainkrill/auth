from django.apps import AppConfig


class MumbleServiceConfig(AppConfig):
    name = 'allianceauth.services.modules.mumble'
    label = 'mumble'
