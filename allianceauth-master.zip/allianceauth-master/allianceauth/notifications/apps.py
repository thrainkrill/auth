from django.apps import AppConfig


class NotificationsConfig(AppConfig):
    name = 'allianceauth.notifications'
    label = 'notifications'
