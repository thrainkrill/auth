from django.apps import AppConfig


class HRApplicationsConfig(AppConfig):
    name = 'allianceauth.hrapplications'
    label = 'hrapplications'
