default_app_config = 'allianceauth.hrapplications.apps.HRApplicationsConfig'
