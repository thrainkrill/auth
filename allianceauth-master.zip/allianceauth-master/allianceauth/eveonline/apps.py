from django.apps import AppConfig


class EveonlineConfig(AppConfig):
    name = 'allianceauth.eveonline'
    label = 'eveonline'
