default_app_config = 'allianceauth.eveonline.apps.EveonlineConfig'
