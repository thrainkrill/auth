default_app_config = 'allianceauth.eveonline.autogroups.apps.EveAutogroupsConfig'
