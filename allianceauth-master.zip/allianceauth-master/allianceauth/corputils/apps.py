from django.apps import AppConfig


class CorpUtilsConfig(AppConfig):
    name = 'allianceauth.corputils'
    label = 'corputils'
